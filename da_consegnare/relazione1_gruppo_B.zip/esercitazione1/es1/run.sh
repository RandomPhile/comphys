#!/bin/bash
g++ main.cpp -o main.out
./main.out