#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
extern int N;
extern int M;
extern ofstream dati;

#define LOG(x) cout<<x<<endl;